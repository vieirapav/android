package com.pav.v1.cliente;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;


public class CadastroUsuarioActivity extends AppCompatActivity {

    Button btnVoltar;
    EditText edtNome;
    EditText edtEmial;
    EditText edtSenha;
    EditText edtRepitaSenha;

    CheckBox ckboxTermos;

    boolean isFormularioOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);

        initFormulario();

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isFormularioOK = true;

                if (TextUtils.isEmpty(edtNome.getText().toString())) {
                    edtNome.setError("*");
                    edtNome.requestFocus();
                    isFormularioOK = false;
                }
                if (TextUtils.isEmpty(edtEmial.getText().toString())) {
                    edtEmial.setError("*");
                    edtEmial.requestFocus();
                    isFormularioOK = false;
                }
                if (TextUtils.isEmpty(edtSenha.getText().toString())) {
                    edtSenha.setError("*");
                    edtSenha.requestFocus();
                    isFormularioOK = false;
                }
                if (TextUtils.isEmpty(edtRepitaSenha.getText().toString())) {
                    edtRepitaSenha.setError("*");
                    edtRepitaSenha.requestFocus();
                    isFormularioOK = false;
                }

                if (!ckboxTermos.isChecked()) {
                    isFormularioOK = false;
                }

                if (isFormularioOK) {

                    if(!validarSenha()){
                        edtSenha.setError("*");
                        edtRepitaSenha.setError("*");
                        edtSenha.requestFocus();
                        Toast.makeText(getApplicationContext(), "As senha digitadas não conferem!", Toast.LENGTH_LONG).show();

                    }else {
                        Intent iMenuPrincipla = new Intent(CadastroUsuarioActivity.this, MainActivity.class);
                        startActivity(iMenuPrincipla);
                    }
                }
            }
        });

    }
    private void initFormulario() {

        btnVoltar = findViewById(R.id.btnVoltar);
        edtNome = findViewById(R.id.edtNome);
        edtEmial = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        edtRepitaSenha = findViewById(R.id.edtRepitaSenha);
        ckboxTermos = findViewById(R.id.ckboxTermos);
        isFormularioOK = false;
    }

    public void ValidarTermo(View view) {

        if (!ckboxTermos.isChecked()) {
            Toast.makeText(getApplicationContext(), "É necessário aceitar os termos de uso para continuar o cadastro", Toast.LENGTH_LONG).show();
        }
    }

    public boolean validarSenha(){
        boolean retorno = false;

        int senhaA,senhaB;

        senhaA = Integer.parseInt(edtSenha.getText().toString());
        senhaB = Integer.parseInt(edtRepitaSenha.getText().toString());

        retorno = (senhaA == senhaB);
        return retorno;
    }
}