package com.pav.v1.cliente;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        iniciarAplicatico();

    }

    private void iniciarAplicatico() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent iSplash = new Intent(SplashActivity.this,LoginActivity.class);
                startActivity(iSplash);
                finish();
                return;

            }
        },AppUtil.TIME_SPLASH);

    }
}
